from django.urls import path
from .views import RandomProductsByCategoryAPIView, AddProductAPIView, SearchHardwareAPIView,FuzzySearchHardwareAPIView, SyncProductsAPIView
urlpatterns = [
    path('random-products-by-category/', RandomProductsByCategoryAPIView.as_view(), name='random-products-by-category'),
    path('add-product/', AddProductAPIView.as_view(), name='add-product'),
    path('search-hardware/', SearchHardwareAPIView.as_view(), name='search-hardware'),
    path('fuzzy-search/', FuzzySearchHardwareAPIView.as_view(), name='fuzzy-search-hardware'),
    path('sync-products/', SyncProductsAPIView.as_view(), name='sync-products'),

]
