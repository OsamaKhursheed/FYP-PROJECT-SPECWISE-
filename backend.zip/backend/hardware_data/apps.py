from django.apps import AppConfig


class HardwareDataConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hardware_data'
