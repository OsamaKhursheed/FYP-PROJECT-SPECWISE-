from rest_framework.views import APIView
from rest_framework.response import Response
from .models import Product
from rest_framework import status
from .serializers import ProductSerializer
from django.db.models import Q
from rapidfuzz import process, fuzz  # Use fuzzy matching
from django.http import JsonResponse
import traceback

class RandomProductsByCategoryAPIView(APIView):
    def get(self, request):
        # Get distinct categories excluding 'Supplies' and excluding products from store_id 1
        store_id = request.GET.get('store_id', None)  # Optionally get the store_id from request parameters
        products = Product.objects.exclude(store_id=1).exclude(category="Supplies").values('category').distinct()
        random_products = []

        for product in products:
            # Fetch random products per category, excluding products from store_id 1 and 'Supplies' category
            category_products = Product.objects.filter(category=product['category']).exclude(store_id=1).exclude(category="Supplies").order_by('?')[:2]
            random_products.extend(category_products.values())

        return Response(random_products, status=status.HTTP_200_OK)


class AddProductAPIView(APIView):
    def post(self, request):
        # Set default values for 'rating', 'link', and 'store_id' if not provided
        data = request.data
        if 'rating' not in data:
            data['rating'] = None
        if 'link' not in data:
            data['link'] = None
        if 'store_id' not in data:
            return Response({"error": "store_id is required."}, status=status.HTTP_400_BAD_REQUEST)

        # Serialize the data and save the product
        serializer = ProductSerializer(data=data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class SearchHardwareAPIView(APIView):
    def get(self, request):
        hardware_name = request.GET.get('hardware_name', '')
        hardware_type = request.GET.get('hardware_type', '')
        store_id = request.GET.get('store_id', None)  # Optionally filter by store_id

        if not hardware_name:
            return Response({"error": "Please provide a hardware name."}, status=status.HTTP_400_BAD_REQUEST)

        # Perform a case-insensitive partial match on 'name' and optional 'category'
        query = Q(name__icontains=hardware_name)
        if hardware_type:
            query &= Q(category__icontains=hardware_type)
        if store_id:
            query &= Q(store_id=store_id)  # Filter by store_id if provided

        matching_products = Product.objects.filter(query).exclude(store_id=1).exclude(category="Supplies")

        serializer = ProductSerializer(matching_products, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class FuzzySearchHardwareAPIView(APIView):
    def get(self, request):
        hardware_name = request.query_params.get('hardware_name', '')
        hardware_type = request.query_params.get('hardware_type', '')
        store_id = request.query_params.get('store_id', None)  # Optionally filter by store_id

        if not hardware_name or not hardware_type:
            return Response({'error': 'Missing hardware_name or hardware_type'}, status=400)

        # Fetch all product names in the same category
        products = Product.objects.filter(category__icontains=hardware_type)
        if store_id:
            products = products.filter(store_id=store_id)  # Filter by store_id if provided

        product_names = [product.name for product in products]

        # Use fuzzy matching to get top 3 matches
        best_matches = process.extract(hardware_name, product_names, scorer=fuzz.token_sort_ratio, limit=3)

        # Get actual product objects for top matches
        matched_products = []
        for match_name, score, _ in best_matches:
            try:
                product = products.get(name=match_name)
                matched_products.append(ProductSerializer(product).data)
            except Product.DoesNotExist:
                continue

        return Response(matched_products, status=status.HTTP_200_OK)


class SyncProductsAPIView(APIView):
    def post(self, request):
        try:
            products = request.data if isinstance(request.data, list) else [request.data]
            synced = []
            created_count = 0
            updated_count = 0

            for item in products:
                link = item.get("link")
                if not link:
                    continue  # Skip if no link

                # Convert rating safely
                rating = item.get("rating")
                try:
                    rating = float(rating)
                except (TypeError, ValueError):
                    rating = None

                defaults = {
                    "name": item.get("name", ""),
                    "category": item.get("category", ""),
                    "price": item.get("price", ""),
                    "rating": rating,
                    "store_id": item.get("store_id")
                }

                # Update or create the product
                product, created = Product.objects.update_or_create(
                    link=link,
                    defaults=defaults
                )
                synced.append(ProductSerializer(product).data)

                if created:
                    created_count += 1
                else:
                    updated_count += 1

            return Response({
                "status": "success",
                "synced": synced,
                "created": created_count,
                "updated": updated_count
            }, status=status.HTTP_200_OK)

        except Exception as e:
            print("❌ Exception in sync_products:", e)
            traceback.print_exc()
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
