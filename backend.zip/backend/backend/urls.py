from django.urls import path, include
from django.contrib import admin
from users.views import RegisterView, home_view, CheckUsernameView
from hardware_data import views  # Import the views module from the hardware_data app

urlpatterns = [
    path('', home_view, name='home'),
    path('admin/', admin.site.urls),
    path('api/register/', RegisterView.as_view(), name='register'),
    path('api/check_username/<str:username>/', CheckUsernameView.as_view(), name='check_username'),    
    path('api/', include('users.urls')),
    path('api/', include('recommendations.urls')),  # Include the app's URLs
    path('api/hardware-data/', include('hardware_data.urls')),  # Include hardware_data URLs
    path('api/history/', include('history.urls')),  # Add this line
    path('api/review/', include('review.urls')),
    
]