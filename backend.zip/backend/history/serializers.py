from rest_framework import serializers
from recommendations.models import QuestionHistory, RecommendationDetails, HardwareRecommendation

class RecommendationDetailsSerializer(serializers.ModelSerializer):
    class Meta:
        model = RecommendationDetails
        fields = '__all__'

class HardwareRecommendationSerializer(serializers.ModelSerializer):
    class Meta:
        model = HardwareRecommendation
        fields = '__all__'

class QuestionHistoryFullSerializer(serializers.ModelSerializer):
    recommendation_details = RecommendationDetailsSerializer(source='recommendationdetails', read_only=True)
    hardware_recommendations = HardwareRecommendationSerializer(many=True, source='hardwarerecommendation_set', read_only=True)

    class Meta:
        model = QuestionHistory
        fields = ['id', 'user', 'question', 'is_hardware', 'timestamp', 'recommendation_details', 'hardware_recommendations']
