from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from recommendations.models import QuestionHistory, RecommendationDetails, HardwareRecommendation
from django.shortcuts import get_object_or_404
from django.contrib.auth.models import User
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt

@api_view(['GET'])
def get_history(request):
    user_id = request.query_params.get('user_id')

    if not user_id:
        return Response({"error": "User ID is required."}, status=status.HTTP_400_BAD_REQUEST)

    try:
        user = get_object_or_404(User, id=user_id)
        # Fetch the user's QuestionHistory
        question_history = QuestionHistory.objects.filter(user=user).values('id', 'question', 'timestamp')

        if question_history.exists():
            return Response({"history": list(question_history)}, status=status.HTTP_200_OK)
        else:
            return Response({"message": "No history found for this user."}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



# View to fetch question details and recommendations by question_id
@csrf_exempt
def get_question_and_recommendations(request):
    # Get the question_id from query parameters
    question_id = request.GET.get('question_id')
    print("Received question_id:", question_id)  # Debug print

    if not question_id:
        print("No question_id provided in the request.")  # Debug print
        return JsonResponse({'error': 'question_id is required'}, status=400)
    
    try:
        # Fetch the QuestionHistory instance by question_id
        print(f"Fetching QuestionHistory with id={question_id}")  # Debug print
        question_history = QuestionHistory.objects.get(id=question_id)
        print("QuestionHistory found:", question_history.question)  # Debug print
        
        # Fetch associated RecommendationDetails and HardwareRecommendation
        recommendations = RecommendationDetails.objects.filter(question_history=question_history)
        hardware_recommendations = HardwareRecommendation.objects.filter(question_history=question_history)

        # Prepare the response data
        data = {
            'question': question_history.question,
            'timestamp': question_history.timestamp,
            'recommendations': [],
            'hardware_recommendations': []
        }

        # Add recommendation details to the response
        for rec in recommendations:
            data['recommendations'].append({
                'software_name': rec.software_name,
                'task_to_perform': rec.task_to_perform,
                'hardware_mentioned': rec.hardware_mentioned,
                'special_task': rec.special_task,
            })
        
        # Add hardware recommendations to the response
        for hardware_rec in hardware_recommendations:
            data['hardware_recommendations'].append({
                'recommendation_type': hardware_rec.recommendation_type,
                'hardware_type': hardware_rec.hardware_type,
                'option1': hardware_rec.option1,
                'option2': hardware_rec.option2,
                'note': hardware_rec.note,
            })
        
        return JsonResponse(data)

    except QuestionHistory.DoesNotExist:
        print(f"QuestionHistory with id={question_id} not found.")  # Debug print
        return JsonResponse({'error': 'QuestionHistory not found'}, status=404)
