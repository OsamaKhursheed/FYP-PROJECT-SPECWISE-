from django.urls import path
from . import views
from .views import get_question_and_recommendations

urlpatterns = [
    path('get_history/', views.get_history, name='get_history'),
    path('history_recommendations/', views.get_question_and_recommendations, name='get_question_recommendations'),
]
