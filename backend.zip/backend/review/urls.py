# review/urls.py
from django.urls import path
from .views import list_reviews, user_review_history, update_review, send_review_reminder

urlpatterns = [
    path('list/', list_reviews, name='list_reviews'),
    path('user/<int:user_id>/', user_review_history, name='user_review_history'),
    path('update/<int:review_id>/', update_review, name='update_review'),
    path('send_review_reminder/', send_review_reminder, name='send_review_reminder'),
]
