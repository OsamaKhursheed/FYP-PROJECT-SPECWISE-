from django.urls import path
from django.http import HttpResponseRedirect
from django.contrib import admin, messages
import requests
from .models import Review

class ReviewAdmin(admin.ModelAdmin):
    list_display = ('user', 'question', 'review_rating', 'review_status', 'review_date', 'current_date')
    list_filter = ('review_status', 'review_rating')
    search_fields = ('user__username', 'question__question')
    list_per_page = 10
    readonly_fields = ['review_date', 'current_date']

    def get_urls(self):
        urls = super().get_urls()
        custom_urls = [
            path('send-reminder/', self.admin_site.admin_view(self.send_reminder), name='send-review-reminder'),
        ]
        return custom_urls + urls

    def send_reminder(self, request):
        try:
            response = requests.get('http://127.0.0.1:8000/api/review/send_review_reminder/')
            if response.status_code == 200:
                self.message_user(request, "Reminders sent successfully.", messages.SUCCESS)
            else:
                self.message_user(request, f"Error sending reminders: {response.status_code}", messages.ERROR)
        except Exception as e:
            self.message_user(request, f"Failed to send reminder: {str(e)}", messages.ERROR)

        return HttpResponseRedirect("../")

admin.site.register(Review, ReviewAdmin)
