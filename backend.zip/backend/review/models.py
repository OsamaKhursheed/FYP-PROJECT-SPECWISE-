from django.db import models
from django.contrib.auth.models import User
from recommendations.models import QuestionHistory  # or wherever your QuestionHistory model is

class Review(models.Model):
    question = models.ForeignKey(QuestionHistory, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)
    review_date = models.DateTimeField(null=True, blank=True)  # Add this field
    review_rating = models.IntegerField(default=0)
    review_content = models.TextField(default="No review yet.")
    review_status = models.BooleanField(default=False)  # Add this field
    current_date = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return f"Review by {self.user.username if self.user else 'Guest'} - QID {self.question.id}"
