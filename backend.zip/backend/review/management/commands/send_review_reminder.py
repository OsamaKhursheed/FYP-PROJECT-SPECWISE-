# reviews/management/commands/send_review_reminder.py

from django.core.management.base import BaseCommand
from django.core.mail import send_mail
from django.utils import timezone
from review.models import Review  # Assuming Review is the model for storing reviews
from django.contrib.auth.models import User  # Assuming the users are from the default User model
from datetime import timedelta

class Command(BaseCommand):
    help = 'Send reminder emails for unreviewed reviews'

    def handle(self, *args, **kwargs):
        # Get the current date and time
        today = timezone.now()

        # Find all reviews that are unreviewed (review_status == False or 0)
        unreviewed_reviews = Review.objects.filter(review_status=False)

        for review in unreviewed_reviews:
            user = review.user  # Assuming a foreign key relationship between Review and User
            # Ensure that the review was created more than a day ago
            if review.created_at < today - timedelta(days=1):
                # Send reminder email
                subject = "Reminder: Please Review Your Experience"
                message = f"Dear {user.first_name},\n\nPlease take a moment to review the product/question: {review.question_text}. We value your feedback!\n\nReview Link: [Your Review Link Here]\n\nThank you!"
                recipient_list = [user.email]
                
                # Send the email
                send_mail(subject, message, 'no-reply@yourdomain.com', recipient_list)

        self.stdout.write(self.style.SUCCESS('Successfully sent review reminders to users'))
