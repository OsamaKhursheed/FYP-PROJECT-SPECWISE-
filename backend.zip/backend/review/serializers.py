# review/serializers.py
from rest_framework import serializers
from .models import Review

class ReviewSerializer(serializers.ModelSerializer):
    question_text = serializers.CharField(source='question.question', read_only=True)
    
    # Add the review_status field to the serializer
    review_status = serializers.BooleanField(read_only=True)

    class Meta:
        model = Review
        fields = ['id', 'question_text', 'review_rating', 'review_content', 'review_date', 'review_status']

    def get_user(self, obj):
        return obj.user.username if obj.user else "Guest"
