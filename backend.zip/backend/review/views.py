# review/views.py
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework import status
from .models import Review
from .serializers import ReviewSerializer
from django.contrib.auth.models import User
from .models import Review, QuestionHistory
from datetime import datetime
from django.core.mail import send_mail
from django.http import JsonResponse
from django.utils import timezone
from datetime import timedelta

@api_view(['GET'])
def list_reviews(request):
    try:
        reviews = Review.objects.all().order_by('-review_date')
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except Exception as e:
        return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET'])
def user_review_history(request, user_id):
    try:
        user = User.objects.get(id=user_id)
        reviews = Review.objects.filter(user=user).order_by('-review_date')
        serializer = ReviewSerializer(reviews, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)
    except User.DoesNotExist:
        return Response({'error': 'User not found.'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['PUT'])
def update_review(request, review_id):
    try:
        review = Review.objects.get(id=review_id)
    except Review.DoesNotExist:
        return Response({'error': 'Review not found'}, status=status.HTTP_404_NOT_FOUND)

    # Update the review's rating and content
    review.review_rating = request.data.get('review_rating', review.review_rating)
    review.review_content = request.data.get('review_content', review.review_content)

    # Set review_status to True and update review_date to the current date
    review.review_status = True
    review.review_date = datetime.now()

    # Save the updated review
    review.save()

    # Serialize the updated review and return the response
    serializer = ReviewSerializer(review)
    return Response(serializer.data, status=status.HTTP_200_OK)


def send_review_reminder(request):
    # Get the current time
    today = timezone.now()
    
    # Filter reviews that are unreviewed (review_status=False)
    unreviewed_reviews = Review.objects.filter(review_status=False)

    emails_sent = 0
    for review in unreviewed_reviews:
        # Only send reminders for reviews created in the last 10 minutes
        if review.current_date < today - timedelta(minutes=10):
            user = review.user
            # Access the question_text from the related QuestionHistory model
            question_text = review.question.question  # This accesses the 'question' field from QuestionHistory

            # Generate the user-specific history page link
            user_history_link = f"http://localhost:3000/user-review-history/{user.id}"

            subject = "Reminder: Please Review Your Experience"
            message = f"Dear {user.first_name},\n\nPlease take a moment to review the product/question: {question_text}. We value your feedback!\n\nReview Link: {user_history_link}\n\nTo view your review history  \n\nThank you!"
            recipient_list = [user.email]
            
            # Send email to the user
            send_mail(subject, message, 'no-reply@yourdomain.com', recipient_list)
            emails_sent += 1

    return JsonResponse({'status': 'success', 'emails_sent': emails_sent})