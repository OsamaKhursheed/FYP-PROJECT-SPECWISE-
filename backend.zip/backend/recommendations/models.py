from django.db import models
from django.contrib.auth.models import User

# Existing QuestionHistory model
class QuestionHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True)  # null for guests
    question = models.TextField()
    is_hardware = models.BooleanField(default=False)  # NEW FIELD
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user if self.user else 'Guest'} - {self.question[:50]}"

# New RecommendationDetails model to store the extracted information
class RecommendationDetails(models.Model):
    question_history = models.ForeignKey(QuestionHistory, on_delete=models.CASCADE)  # Link to QuestionHistory
    software_name = models.CharField(max_length=255, default="None")
    task_to_perform = models.CharField(max_length=255, default="None")
    hardware_mentioned = models.CharField(max_length=255, default="PC")
    special_task = models.CharField(max_length=255, default="None")

    def __str__(self):
        return f"Recommendation for {self.question_history.question[:50]}"


# models.py
class HardwareRecommendation(models.Model):
    question_history = models.ForeignKey(QuestionHistory, on_delete=models.CASCADE)
    recommendation_type = models.CharField(max_length=20, choices=[
        ('minimum', 'Minimum'), 
        ('suitable', 'Suitable')
    ])
    hardware_type = models.CharField(max_length=50)  # e.g., CPU, GPU
    option1 = models.CharField(max_length=255)
    option2 = models.CharField(max_length=255)
    note = models.TextField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.question_history} - {self.hardware_type} ({self.recommendation_type})"
    

