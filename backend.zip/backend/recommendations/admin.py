# admin.py

from django.contrib import admin
from .models import QuestionHistory, RecommendationDetails, HardwareRecommendation

# Admin for QuestionHistory model
class QuestionHistoryAdmin(admin.ModelAdmin):
    list_display = ('user', 'question', 'is_hardware', 'timestamp')
    list_filter = ('is_hardware',)
    search_fields = ('user__username', 'question')
    list_per_page = 10  # Number of records per page

admin.site.register(QuestionHistory, QuestionHistoryAdmin)


# Admin for RecommendationDetails model
class RecommendationDetailsAdmin(admin.ModelAdmin):
    list_display = ('question_history', 'software_name', 'task_to_perform', 'hardware_mentioned', 'special_task')
    search_fields = ('question_history__question', 'software_name', 'task_to_perform')
    list_filter = ('software_name', 'task_to_perform')  # Optional filters for fields
    list_per_page = 10  # Number of records per page

admin.site.register(RecommendationDetails, RecommendationDetailsAdmin)


# Admin for HardwareRecommendation model
class HardwareRecommendationAdmin(admin.ModelAdmin):
    list_display = ('question_history', 'recommendation_type', 'hardware_type', 'option1', 'option2', 'note', 'created_at')
    list_filter = ('recommendation_type', 'hardware_type')
    search_fields = ('question_history__question', 'hardware_type', 'option1', 'option2')
    list_per_page = 10  # Number of records per page

admin.site.register(HardwareRecommendation, HardwareRecommendationAdmin)
