// src/Home.js
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './components/styles.css';
import Navbar from '../components/maincomponents/Navbar';
import HeroSection from './components/HeroSection';
import HowItWorks from './components/HowItWorks';
import WhyChooseUs from './components/WhyChooseUs';
import Ready from './components/Ready';
import FAQSection from './components/FAQSection';
import Footer from '../components/maincomponents/Footer';
import axios from 'axios';

const Home = () => {
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const navigate = useNavigate();

  return (
    <>
      <Navbar backgroundColor="#2C3E50" pageName="home" />
      <HeroSection />
      <HowItWorks />
      <WhyChooseUs />
      <Ready />
      <FAQSection />

      <Footer />
    </>
  );
};

export default Home;
