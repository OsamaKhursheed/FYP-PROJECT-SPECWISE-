import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import Navbar from '../components/maincomponents/Navbar';
import Footer from '../components/maincomponents/Footer';
import ReviewModal from './ReviewModal'; // Import the modal component

const UserReviewHistory = () => {
  const { userId } = useParams();
  const [reviews, setReviews] = useState([]);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false); // State for showing the modal
  const [currentReviewId, setCurrentReviewId] = useState(null); // Track the review ID for the modal
  const [filter, setFilter] = useState('all'); // State to hold the current filter value
  const [sortedReviews, setSortedReviews] = useState([]); // State to hold sorted reviews

  useEffect(() => {
    if (userId) {
      axios.get(`http://127.0.0.1:8000/api/review/user/${userId}/`)
        .then(res => {
          setReviews(res.data);
          setSortedReviews(res.data); // Initially show all reviews
        })
        .catch(err => {
          setError('Error fetching reviews: ' + err.message);
        });
    } else {
      setError("User ID is missing in the URL");
    }
  }, [userId]);

  const handleReviewSubmit = (reviewId, reviewContent, reviewRating) => {
    // Update the review using the API
    axios.put(`http://127.0.0.1:8000/api/review/update/${reviewId}/`, {
      review_content: reviewContent,
      review_rating: reviewRating,
      review_status: true, // Update review status to true
    })
      .then((response) => {
        console.log('Review updated successfully:', response.data);
        setReviews(reviews.map((review) =>
          review.id === reviewId ? { ...review, review_content: reviewContent, review_rating: reviewRating, review_status: true } : review
        ));
      })
      .catch((error) => {
        console.error('Error updating review:', error);
      });
  };

  const handleOpenModal = (reviewId) => {
    setCurrentReviewId(reviewId); // Set the current review ID for the modal
    setShowModal(true); // Show the modal
  };

  const handleCloseModal = () => {
    setShowModal(false); // Close the modal
  };

  const handleFilterChange = (e) => {
    const selectedFilter = e.target.value;
    setFilter(selectedFilter);

    let filteredReviews;
    if (selectedFilter === 'pending') {
      filteredReviews = reviews.filter((review) => review.review_status === false || review.review_status === 0);
    } else if (selectedFilter === 'completed') {
      filteredReviews = reviews.filter((review) => review.review_status === true);
    } else if (selectedFilter === 'date') {
      filteredReviews = [...reviews].sort((a, b) => new Date(b.review_date) - new Date(a.review_date)); // Sort by date descending
    } else {
      filteredReviews = reviews; // Show all reviews
    }

    setSortedReviews(filteredReviews);
  };

  return (
    <>
      <Navbar />

      <div className="container mt-5 mb-5">
        <h2 className="text-center mb-4">⭐ Your Review History ⭐</h2>

        {error && <div className="alert alert-danger">{error}</div>}

        {/* Filter options */}
        <div className="d-flex justify-content-between mb-3">
          <select className="form-select w-auto" value={filter} onChange={handleFilterChange}>
            <option value="all">All Reviews</option>
            <option value="pending">Pending Reviews</option>
            <option value="completed">Completed Reviews</option>
            <option value="date">Sort by Date</option>
          </select>
        </div>

        {sortedReviews.length === 0 ? (
          <div className="alert alert-info">You have no reviews yet.</div>
        ) : (
          <div className="row">
            {sortedReviews.map((review, index) => (
              <div key={index} className="col-md-6 mb-4">
                <div className="card shadow-sm border-0 h-100">
                  <div className="card-body">
                    <h5 className="card-title">{review.question_text}</h5>
                    <p className="card-text"><strong>Rating:</strong> {review.review_rating} / 5</p>
                    <p className="card-text"><strong>Review:</strong> {review.review_content}</p>
                    <p className="text-muted small"><strong>Date:</strong> {new Date(review.review_date).toLocaleString()}</p>

                    {/* Change button text based on review status */}
                    {(review.review_status === false || review.review_status === 0) && (
                      <button
                        className="btn btn-primary mt-3"
                        onClick={() => handleOpenModal(review.id)} // Open modal on button click
                      >
                        Write a Review
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />

      {/* Modal for review input */}
      <ReviewModal
        showModal={showModal}
        handleClose={handleCloseModal}
        reviewId={currentReviewId}
        handleReviewSubmit={handleReviewSubmit}
      />
    </>
  );
};

export default UserReviewHistory;
