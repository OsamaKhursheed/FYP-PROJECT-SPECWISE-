import React, { useState } from 'react';

const ReviewModal = ({ showModal, handleClose, reviewId, handleReviewSubmit }) => {
  const [reviewContent, setReviewContent] = useState('');
  const [reviewRating, setReviewRating] = useState(0);

  const handleSubmit = () => {
    // Submit the review to the backend using axios
    handleReviewSubmit(reviewId, reviewContent, reviewRating);
    handleClose(); // Close the modal after submitting
  };

  if (!showModal) return null;

  return (
    <div className="modal show" style={{ display: 'block' }} onClick={handleClose}>
      <div className="modal-dialog" onClick={(e) => e.stopPropagation()}>
        <div className="modal-content">
          <div className="modal-header">
            <h5 className="modal-title">Submit Your Review</h5>
            <button type="button" className="close" onClick={handleClose}>
              <span>&times;</span>
            </button>
          </div>
          <div className="modal-body">
            <div className="form-group">
              <label htmlFor="reviewRating">Rating (1-5):</label>
              <input
                type="number"
                id="reviewRating"
                className="form-control"
                value={reviewRating}
                onChange={(e) => setReviewRating(e.target.value)}
                min="1"
                max="5"
              />
            </div>
            <div className="form-group">
              <label htmlFor="reviewContent">Review:</label>
              <textarea
                id="reviewContent"
                className="form-control"
                value={reviewContent}
                onChange={(e) => setReviewContent(e.target.value)}
                rows="4"
              ></textarea>
            </div>
          </div>
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={handleClose}>
              Close
            </button>
            <button type="button" className="btn btn-primary" onClick={handleSubmit}>
              Submit Review
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewModal;
