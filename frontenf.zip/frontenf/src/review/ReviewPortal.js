// src/Review/ReviewPortal.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import Navbar from '../components/maincomponents/Navbar';
import Footer from '../components/maincomponents/Footer';
import { FaStar } from 'react-icons/fa';
import './ReviewPortal.css'; // optional CSS file for custom styles

const ReviewPortal = () => {
  const [reviews, setReviews] = useState([]);
  const [filteredReviews, setFilteredReviews] = useState([]);
  const [expanded, setExpanded] = useState({});
  const [filter, setFilter] = useState('date'); // Default filter by date

  useEffect(() => {
    axios.get('http://127.0.0.1:8000/api/review/list/')
      .then(res => {
        // Filter out only reviewed reviews (assuming `review_status` is true for reviewed)
        const reviewed = res.data.filter(review => review.review_status === true);
        setReviews(reviewed);
        setFilteredReviews(reviewed); // Set filtered reviews as reviewed ones initially
      })
      .catch(err => console.error('Error fetching reviews:', err));
  }, []);

  const toggleExpand = (index) => {
    setExpanded(prev => ({ ...prev, [index]: !prev[index] }));
  };

  const getShortenedText = (text, index) => {
    const words = text.split(' ');
    if (words.length <= 10) return text;
    return expanded[index] ? text : words.slice(0, 10).join(' ') + '...';
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <FaStar key={i} color={i < rating ? "#ffc107" : "#e4e5e9"} size={18} />
    ));
  };

  const handleFilterChange = (e) => {
    const selectedFilter = e.target.value;
    setFilter(selectedFilter);

    let sortedReviews;
    if (selectedFilter === 'date') {
      // Sort reviews by date (most recent first)
      sortedReviews = [...reviews].sort((a, b) => new Date(b.review_date) - new Date(a.review_date));
    } else if (selectedFilter === 'rating') {
      // Sort reviews by rating (highest first)
      sortedReviews = [...reviews].sort((a, b) => b.review_rating - a.review_rating);
    }

    setFilteredReviews(sortedReviews);
  };

  return (
    <>
      <Navbar />
      <div className="container mt-5 mb-5">
        <h2 className="text-center mb-4 fw-bold">⭐ User Review Portal ⭐</h2>

        {/* Filter options */}
        <div className="d-flex justify-content-between mb-3">
          <select className="form-select w-auto" value={filter} onChange={handleFilterChange}>
            <option value="date">Sort by Date</option>
            <option value="rating">Sort by Rating</option>
          </select>
        </div>

        {filteredReviews.length === 0 ? (
          <div className="alert alert-info text-center">No reviews available yet.</div>
        ) : (
          <div className="row">
            {filteredReviews.map((review, index) => (
              <div key={index} className="col-md-6 col-lg-4 mb-4">
                <div className="card border-0 shadow-lg rounded h-100 p-3">
                  <div className="card-body d-flex flex-column justify-content-between">
                    <div className="mb-3">
                      <h6 className="fw-semibold text-primary mb-2">Question</h6>
                      <p className="text-dark">
                        {getShortenedText(review.question_text || "N/A", index)}
                        {review.question_text && review.question_text.split(' ').length > 10 && (
                          <span
                            className="text-decoration-none text-info ms-2"
                            role="button"
                            onClick={() => toggleExpand(index)}
                            style={{ fontSize: "0.85rem" }}
                          >
                            {expanded[index] ? 'See Less' : 'See More'}
                          </span>
                        )}
                      </p>
                    </div>

                    <div className="mb-2">
                      <h6 className="fw-semibold text-success mb-1">Rating</h6>
                      <div>{renderStars(review.review_rating)} <span className="text-muted">({review.review_rating}/5)</span></div>
                    </div>

                    <div className="mb-3">
                      <h6 className="fw-semibold text-secondary mb-1">Review</h6>
                      <p className="text-body">{review.review_content}</p>
                    </div>

                    <p className="text-muted small text-end mt-auto">
                      <i>Reviewed on {new Date(review.review_date).toLocaleDateString()}</i>
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </>
  );
};

export default ReviewPortal;
