import React, { useEffect, useState } from 'react';
import './HistoryModal.css';
import { FaLaptopCode, FaTasks, FaMicrochip, FaStar } from 'react-icons/fa';

const HistoryModal = ({ selectedItem }) => {
  const [details, setDetails] = useState(null);
  const [error, setError] = useState('');
  const [expandedNotes, setExpandedNotes] = useState({});

  useEffect(() => {
    const fetchHistoryDetails = async () => {
      if (!selectedItem) return;
      try {
        const res = await fetch(`http://127.0.0.1:8000/api/history/history_recommendations/?question_id=${selectedItem.id}`);
        const data = await res.json();
        if (res.ok) {
          setDetails(data);
        } else {
          setError(data.error || 'Failed to fetch history details');
        }
      } catch (err) {
        setError('Error fetching history details');
        console.error(err);
      }
    };
    fetchHistoryDetails();
  }, [selectedItem]);

  const toggleNote = (index) => {
    setExpandedNotes((prev) => ({
      ...prev,
      [index]: !prev[index],
    }));
  };

  const truncateNote = (note) => {
    const words = note.split(' ');
    return words.length > 25 ? words.slice(0, 25).join(' ') + '...' : note;
  };

  return (
    <div className="modal fade" id="historyModal" tabIndex="-1" aria-labelledby="historyModalLabel" aria-hidden="true">
      <div className="modal-dialog modal-dialog-centered modal-xl">
        <div className="modal-content enhanced-modal glass-bg">
          <div className="modal-header border-0">
            <h4 className="modal-title fw-bold">🔍 Recommendation Details</h4>
            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close" />
          </div>
          <div className="modal-body">
            {error && <p className="text-danger">{error}</p>}
            {!details ? (
              <p>Loading...</p>
            ) : (
              <>
                <div className="question-section mb-4">
                  <p><strong>❓ Question:</strong> {details.question}</p>
                  <p><strong>🕒 Time:</strong> {new Date(details.timestamp).toLocaleString()}</p>
                </div>

                {/* Summary Cards */}
                <div className="summary-container-glass">
                  <div className="summary-card-glass">
                    <FaLaptopCode className="summary-icon" />
                    <div>
                      <h6>Software</h6>
                      <p>{details.recommendations?.[0]?.software_name || 'None'}</p>
                    </div>
                  </div>
                  <div className="summary-card-glass">
                    <FaTasks className="summary-icon" />
                    <div>
                      <h6>Task</h6>
                      <p>{details.recommendations?.[0]?.task_to_perform || 'N/A'}</p>
                    </div>
                  </div>
                  <div className="summary-card-glass">
                    <FaMicrochip className="summary-icon" />
                    <div>
                      <h6>Hardware</h6>
                      <p>{details.recommendations?.[0]?.hardware_mentioned || 'None'}</p>
                    </div>
                  </div>
                  <div className="summary-card-glass">
                    <FaStar className="summary-icon" />
                    <div>
                      <h6>Special Task</h6>
                      <p>{details.recommendations?.[0]?.special_task || 'None'}</p>
                    </div>
                  </div>
                </div>

                {/* Hardware Sections */}
                <div className="hardware-section mt-4">
                  <h5 className="hardware-title text-success">✅ Suitable Hardware</h5>
                  {details.hardware_recommendations
                    .filter((rec) => rec.recommendation_type === 'suitable')
                    .map((rec, i) => (
                      <div key={`s-${i}`} className="card glass-card mb-3 border-success">
                        <div className="card-body">
                          <p><strong>Hardware:</strong> {rec.hardware_type}</p>
                          <p><strong>Option 1:</strong> {rec.option1}</p>
                          <p><strong>Option 2:</strong> {rec.option2}</p>
                          <p>
                            <strong>Note:</strong>{' '}
                            {expandedNotes[`s-${i}`] ? rec.note : truncateNote(rec.note)}
                            <button className="see-toggle-btn" onClick={() => toggleNote(`s-${i}`)}>
                              {expandedNotes[`s-${i}`] ? 'See Less' : 'See More'}
                            </button>
                          </p>
                        </div>
                      </div>
                    ))}
                </div>

                <div className="hardware-section mt-4">
                  <h5 className="hardware-title text-warning">⚠️ Minimum Hardware</h5>
                  {details.hardware_recommendations
                    .filter((rec) => rec.recommendation_type === 'minimum')
                    .map((rec, i) => (
                      <div key={`m-${i}`} className="card glass-card mb-3 border-warning">
                        <div className="card-body">
                          <p><strong>Hardware:</strong> {rec.hardware_type}</p>
                          <p><strong>Option 1:</strong> {rec.option1}</p>
                          <p><strong>Option 2:</strong> {rec.option2}</p>
                          <p>
                            <strong>Note:</strong>{' '}
                            {expandedNotes[`m-${i}`] ? rec.note : truncateNote(rec.note)}
                            <button className="see-toggle-btn" onClick={() => toggleNote(`m-${i}`)}>
                              {expandedNotes[`m-${i}`] ? 'See Less' : 'See More'}
                            </button>
                          </p>
                        </div>
                      </div>
                    ))}
                </div>
              </>
            )}
          </div>
          <div className="modal-footer border-0">
            <button type="button" className="btn btn-outline-primary" data-bs-dismiss="modal">
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoryModal;
