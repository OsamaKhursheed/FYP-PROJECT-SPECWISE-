import React, { useState, useEffect } from 'react';
import Navbar from '../components/maincomponents/Navbar';
import Footer from '../components/maincomponents/Footer';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
import HistoryModal from './HistoryModal';

const History = () => {
  const [userId, setUserId] = useState(null);
  const [history, setHistory] = useState([]);
  const [sortedHistory, setSortedHistory] = useState([]);
  const [error, setError] = useState('');
  const [selectedItem, setSelectedItem] = useState(null);
  const [sortOrder, setSortOrder] = useState('desc'); // default sort order

  useEffect(() => {
    const userString = localStorage.getItem('user');
    if (userString) {
      const user = JSON.parse(userString);
      if (user?.user_id) {
        setUserId(user.user_id);
      } else {
        setError('User data found but user_id is missing.');
      }
    } else {
      setError('You need to be logged in to view history.');
    }
  }, []);

  const handleFetchHistory = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const userId = user?.user_id || null;

      const response = await fetch(`http://127.0.0.1:8000/api/history/get_history/?user_id=${userId}`);
      const data = await response.json();

      if (response.ok) {
        setHistory(data.history);
        sortHistory(data.history, sortOrder); // sort on initial load
        setError('');
      } else {
        setError(data.error || data.message);
      }
    } catch (err) {
      setError('Error fetching history');
      console.error("Fetch error:", err);
    }
  };

  useEffect(() => {
    if (userId) {
      handleFetchHistory();
    }
  }, [userId]);

  const sortHistory = (data, order) => {
    const sorted = [...data].sort((a, b) => {
      return order === 'asc'
        ? new Date(a.timestamp) - new Date(b.timestamp)
        : new Date(b.timestamp) - new Date(a.timestamp);
    });
    setSortedHistory(sorted);
  };

  const handleSortChange = (e) => {
    const selectedOrder = e.target.value;
    setSortOrder(selectedOrder);
    sortHistory(history, selectedOrder);
  };

  return (
    <>
      <Navbar />
      <div className="container my-5">
      <h1 className="text-center fw-bold display-4 text-primary mb-2">SpecWise</h1>
        <main>
          <h2 className="text-center my-4 text-secondary fs-3">
            📜 Your Personalized Recommendation History
          </h2>
          <p className="text-center text-muted mb-4">
            Track, revisit, and review all your past queries and predictions in one place.
          </p>


          {error && <p className="text-danger text-center">{error}</p>}

          {/* Sort Dropdown */}
          <div className="d-flex justify-content-end mb-3">
            <select className="form-select w-auto" value={sortOrder} onChange={handleSortChange}>
              <option value="desc">Sort by Newest</option>
              <option value="asc">Sort by Oldest</option>
            </select>
          </div>

          <div>
            {sortedHistory.length > 0 ? (
              <table className="table table-striped table-bordered">
                <thead>
                  <tr>
                    <th>Question ID</th>
                    <th>Question</th>
                    <th>Timestamp</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedHistory.map((item, index) => (
                    <tr key={index}>
                      <td>{item.id}</td>
                      <td>{item.question}</td>
                      <td>{new Date(item.timestamp).toLocaleString()}</td>
                      <td>
                        <button
                          className="btn btn-primary btn-sm"
                          data-bs-toggle="modal"
                          data-bs-target="#historyModal"
                          onClick={() => setSelectedItem(item)}
                        >
                          View Details
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              !error && <p className="text-center">No history available for this user.</p>
            )}
          </div>
        </main>
      </div>

      <HistoryModal selectedItem={selectedItem} />
      <Footer />
    </>
  );
};

export default History;
