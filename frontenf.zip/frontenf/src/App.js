// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './Homecomponent/Home';
import Register from './Log-reg/Register';
import Login from './Log-reg/Login';
import AboutUs from './About/AboutUs';
import ContactUs from './Contact/ContactUs'; 
import Recommendations from './Rec/Recommendations';
import History from './History/History';  // Import the new History component
import ReviewPortal from './review/ReviewPortal';
import UserReviewHistory from './review/UserReviewHistory'; // Import the new UserReviewHistory component

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/aboutus" element={<AboutUs />} />
        <Route path="/contactus" element={<ContactUs />} />
        <Route path="/recommendations" element={<Recommendations />} />
        <Route path="/history" element={<History />} />  {/* Add the new route */}
        <Route path="/review-portal" element={<ReviewPortal />} /> {/* ✅ Review Portal Route */}
        <Route path="/user-review-history/:userId" element={<UserReviewHistory />} />  {/* Add new user review history route */}
      </Routes>
    </Router>
  );
}

export default App;
