import React, { useEffect, useState } from 'react';
import './styles.css';
import Logo from './logo/logo.svg';
import { Link } from 'react-router-dom'; // Import Link to use routing

const Navbar = ({ backgroundColor, pageName }) => {
  const [username, setUsername] = useState(null);
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    // Get user data from localStorage
    const storedUser = JSON.parse(localStorage.getItem('user'));
    console.log("Stored User from localStorage:", storedUser);  // Debugging: log the entire stored user object

    if (storedUser && storedUser.username) {
      setUsername(storedUser.username);
      setUserId(storedUser.user_id); // Use 'user_id' instead of 'id'
      console.log("User ID from localStorage:", storedUser.user_id); // Log the user ID
    } else {
      console.log("No user data found in localStorage.");
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('user');
    setUsername(null);
    setUserId(null);
    window.location.href = '/login'; // redirect to login page
  };
  

  return (
    <nav className="navbar navbar-expand-lg" style={{ backgroundColor: backgroundColor || '#3498DB' }}>
      <div className="nav-container">
        <a className="navbar-brand" href="/">
          <img src={Logo} alt="SpecWise Logo" style={{ height: '40px', width: 'auto' }} />
        </a>

        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav ms-auto">
            <li className="nav-item">
              <a className={`nav-link ${pageName === 'home' ? 'active' : ''}`} href="/">Home</a>
            </li>
            <li className="nav-item">
              <a className={`nav-link ${pageName === 'aboutus' ? 'active' : ''}`} href="/aboutus">About Us</a>
            </li>
            <li className="nav-item">
              <a className={`nav-link ${pageName === 'contactus' ? 'active' : ''}`} href="/contactus">Contact Us</a>
            </li>

            {/* Review Portal button for all users */}
            <li className="nav-item">
              <Link to="/review-portal" className="btn btn-info mx-2">
                Review Portal
              </Link>
            </li>

            {username ? (
                <>
                  <li className="nav-item">
                    <Link to={`/user-review-history/${userId}`} className="btn btn-info mx-2">
                      Review History
                    </Link>
                  </li>
                  <li className="nav-item">
                    <Link to="/history" className="btn btn-info mx-2">
                      History
                    </Link>
                  </li>
                  <li className="nav-item">
                    <span className="nav-link">Welcome, <b>{username}</b></span>
                  </li>
                  <li className="nav-item">
                    <button className="btn btn-danger mx-2" onClick={handleLogout}>
                      Logout
                    </button>
                  </li>
                </>
              ) : (

              // Show login and signup buttons if guest
              <>
                <li className="nav-item">
                  <a className={`btn btn-primary mx-2 ${pageName === 'login' ? 'disabled' : ''}`} id="main-b" href="/login">Login</a>
                </li>
                <li className="nav-item">
                  <a className={`btn btn-secondary ${pageName === 'Register' ? 'disabled' : ''}`} id="main-b" href="/Register">Signup</a>
                </li>
              </>
            )}
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
