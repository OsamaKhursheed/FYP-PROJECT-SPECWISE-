import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';

function Details({ finalHardwareRecommendation }) {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const hasFetched = useRef(false); // Prevents double fetch

  useEffect(() => {
    const fetchProducts = async () => {
      if (hasFetched.current || !finalHardwareRecommendation) return;
      hasFetched.current = true;

      try {
        const response = await axios.post("http://127.0.0.1:8000/api/fetch-matched-hardware/", {
          finalHardwareRecommendation,
        });
        
        console.log("✅ API Response:", response.data); // For debugging

        const rawData = response.data.matched_hardware_data; // Access the matched_hardware_data

        // Flatten the nested response
        const extractedProducts = [];
        Object.entries(rawData).forEach(([level, hwTypes]) => {
          Object.entries(hwTypes).forEach(([hwType, options]) => {
            Object.entries(options).forEach(([optLabel, productsList]) => {
              if (Array.isArray(productsList)) {
                productsList.forEach(product => {
                  extractedProducts.push({
                    name: product.name,
                    category: hwType,
                    price: product.price,
                    rating: product.rating || 'N/A', // Use 'N/A' if no rating
                    link: product.link || 'No link available', // Handle missing links
                  });
                });
              }
            });
          });
        });

        setProducts(extractedProducts);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch hardware data");
        setLoading(false);
      }
    };

    fetchProducts();
  }, [finalHardwareRecommendation]);

  return (
    <div className="container mt-4 text-center pt-4">
      <h4 className="mb-4">Hardware Product Details:</h4>

      {loading && <p>Loading products...</p>}
      {error && (
        <div className="alert alert-danger" role="alert">
          {error}
        </div>
      )}

      {products.length > 0 && (
        <div className="table-responsive">
          <table className="table table-bordered table-striped table-hover">
            <thead className="thead bg-primary text-white">
              <tr>
                <th>Name</th>
                <th>Category</th>
                <th>Price</th>
                <th>Rating</th>
                <th>Link</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product, index) => (
                <tr key={index}>
                  <td>{product.name}</td>
                  <td>{product.category}</td>
                  <td>{product.price}</td>
                  <td>{product.rating}</td>
                  <td>
                    {product.link !== 'No link available' ? (
                      <a href={product.link} target="_blank" rel="noopener noreferrer" className="btn btn-primary btn-sm">
                        View Product
                      </a>
                    ) : (
                      product.link
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default Details;
