import React, { useState, useEffect, useRef } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import cpuImage from '../assets/cpu.png';
import gpuImage from '../assets/gpu.png';
import ramImage from '../assets/ram.png';
import ssdImage from '../assets/ssd.png';
import motherboardImage from '../assets/motherboard.png';
import powersupplyImage from '../assets/powersupply.png';
import Details from './Details';

function Recommendation({ inputQuestion, questionId, onRecommendationFetched }) {
  const [questionDetails, setQuestionDetails] = useState(null);
  const [hardwareRecommendation, setHardwareRecommendation] = useState(null);
  const [expandedNote, setExpandedNote] = useState(null);

  const hasFetchedQuestion = useRef(false);
  const hasFetchedHardware = useRef(false);

  const imageMapping = {
    CPU: cpuImage,
    GPU: gpuImage,
    RAM: ramImage,
    SSD: ssdImage,
    Motherboard: motherboardImage,
    PowerSupply: powersupplyImage,
  };

  const fetchQuestionDetails = async () => {
    try {
      const user = JSON.parse(localStorage.getItem('user'));
      const user_id = user?.user_id || null;
  
      const response = await fetch('http://localhost:8000/api/question_details/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ question_id: questionId, user_id }), // ✅ send question_id
      });
      console.log('Question ID in REC:', questionId);
      const data = await response.json();
      setQuestionDetails(data);
    } catch (error) {
      console.error('Error fetching question details:', error);
    }
  };
  
  const fetchHardwareRecommendation = async (details) => {
    try {
      const response = await fetch('http://127.0.0.1:8000/api/hardware_recommendation/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          recommendation_details: details.recommendation_details,
          question_id: questionId,
        }),
      });
  
      const data = await response.json();
      setHardwareRecommendation(data.recommendations);
  
      // Send to parent component
      if (onRecommendationFetched) {
        onRecommendationFetched(data.recommendations);
      }
    } catch (error) {
      console.error('Error fetching hardware recommendation:', error);
    }
  };
  
  


  useEffect(() => {
    if (questionId && !hasFetchedQuestion.current) {
      hasFetchedQuestion.current = true;
      fetchQuestionDetails();
    }
  }, [questionId]);
  

  useEffect(() => {
    if (questionDetails && !hasFetchedHardware.current) {
      hasFetchedHardware.current = true;
      fetchHardwareRecommendation(questionDetails);
    }
  }, [questionDetails]);

  if (!questionDetails || !hardwareRecommendation) {
    return <div>Loading...</div>;
  }

  const truncateNote = (note) => {
    if (!note) return '';
    const limit = 50;
    return note.length > limit ? note.slice(0, limit) + '...' : note;
  };

  const toggleNoteExpansion = (index) => {
    setExpandedNote(expandedNote === index ? null : index);
  };

  const renderHardwareRecommendationSection = (hardwareData, requirementType) => {
    return Object.entries(hardwareData).map(([key, { option1, option2, note }], index) => (
      <div key={index} className="mb-4">
        <div className="d-flex align-items-center mb-3">
          <img src={imageMapping[key]} alt={key} className="img-fluid" style={{ width: '40px', marginRight: '10px' }} />
          <h5 className="text-primary">{key}</h5>
        </div>
        <table className="table table-bordered table-striped">
          <thead>
            <tr>
              <th>Requirement</th>
              <th>Option 1</th>
              <th>Option 2</th>
              <th>Note</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>{requirementType}</td>
              <td>{option1}</td>
              <td>{option2}</td>
              <td>
                <div>
                  {expandedNote === index ? (
                    <p>{note}</p>
                  ) : (
                    <p>{truncateNote(note)}</p>
                  )}
                  {note && note.length > 50 && (
                    <button
                      className="btn btn-link p-0"
                      onClick={() => toggleNoteExpansion(index)}
                    >
                      {expandedNote === index ? 'See Less' : 'See More'}
                    </button>
                  )}
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    ));
  };

  return (
    <div className="container mt-5">
      <h3 className="mb-4 text-center text-success">Question Details</h3>

      <div className="alert alert-info">
        <strong>Input Question:</strong> {questionDetails.question}
      </div>

      <div className="row">
        {Object.entries(questionDetails.recommendation_details || {}).map(([key, value], index) => (
          <div key={index} className="col-md-6 mb-3">
            <div className="card shadow-sm h-100">
              <div className="card-body">
                <h5 className="card-title text-primary">{key}</h5>
                <p className="card-text">{value}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      <h4 className="text-center text-primary">Minimum Hardware Requirements</h4>
      <div>
        {renderHardwareRecommendationSection(hardwareRecommendation.minimum, 'Minimum')}
      </div>

      <h4 className="text-center text-primary">Best Suitable Hardware Requirements</h4>
      <div>
        {renderHardwareRecommendationSection(hardwareRecommendation.suitable, 'Best Suitable')}
      </div>
    </div>
  );
}

export default Recommendation;
