import React from 'react';

function Comparison() {
  return (
    <div className="mt-4">
      <h4>Comparison:</h4>
      <p>Comparison functionality will be added here.</p>
    </div>
  );
}

export default Comparison;
